package jeremi.fakedatagenerator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FakeDataGeneratorApplicationTests {

    @Test
    void contextLoads() {
    }

}
